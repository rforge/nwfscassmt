
cMx <-
function(Input){as.matrix(Input)}
